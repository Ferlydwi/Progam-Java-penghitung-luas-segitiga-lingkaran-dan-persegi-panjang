
package luas.lingkaran;


public class Luas_lingkaran {
    public static void main(String[] args){
        double jarijari = 14;
        double phi = 3.14;
        double luasLingkaran = phi*jarijari*jarijari;
        System.out.println("jarijari = "+jarijari);
        System.out.println("phi = "+phi);
        System.out.println("Luas Lingkaran Adalah = "+luasLingkaran);
    }
    
}
